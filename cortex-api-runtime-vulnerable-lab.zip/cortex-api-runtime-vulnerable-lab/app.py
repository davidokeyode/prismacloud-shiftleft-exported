from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from flask import Flask, Response, jsonify, redirect, request

app = Flask(__name__)

LAB_ROOT = Path(__file__).resolve().parent
DATA_ROOT = LAB_ROOT / "data"

def get_db() -> sqlite3.Connection:
    connection = sqlite3.connect(":memory:")
    connection.row_factory = sqlite3.Row
    connection.executescript(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            role TEXT NOT NULL
        );

        INSERT INTO users (id, username, email, role) VALUES
            (1, 'alice', 'alice@example.invalid', 'user'),
            (2, 'bob', 'bob@example.invalid', 'user'),
            (3, 'admin', 'admin@example.invalid', 'admin');
        """
    )
    return connection

@app.after_request
def add_intentionally_weak_headers(response: Response) -> Response:
    # Intentionally permissive for scanner testing in this localhost-only lab.
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["X-Lab-Warning"] = "Intentionally vulnerable localhost training API"
    return response

@app.get("/")
def index():
    return jsonify(
        {
            "name": "Cortex API Runtime Vulnerable Lab",
            "warning": "Intentionally insecure. Run on localhost only.",
            "endpoints": ["/api/search", "/api/users", "/api/files", "/api/redirect", "/api/debug"],
        }
    )

@app.get("/api/search")
def search():
    # Intentionally reflects untrusted input into HTML for scanner testing.
    query = request.args.get("q", "")
    html = f"<html><body><h1>Search results</h1><p>You searched for: {query}</p></body></html>"
    return Response(html, mimetype="text/html")

@app.get("/api/users")
def users():
    # Intentionally vulnerable read-only SQL query for scanner testing.
    # The database is recreated in memory for each request.
    user_id = request.args.get("id", "1")
    query = f"SELECT id, username, email, role FROM users WHERE id = {user_id}"
    connection = get_db()
    try:
        rows = connection.execute(query).fetchall()
        return jsonify([dict(row) for row in rows])
    except sqlite3.Error as exc:
        # Intentionally verbose error response.
        return jsonify({"error": str(exc), "query": query}), 500
    finally:
        connection.close()

@app.get("/api/files")
def files():
    # Intentionally weak traversal handling, restricted to this lab folder so it
    # cannot read arbitrary host files. "../lab_secret.txt" is deliberately readable.
    filename = request.args.get("name", "welcome.txt")
    requested = (DATA_ROOT / filename).resolve()

    if LAB_ROOT not in requested.parents and requested != LAB_ROOT:
        return jsonify({"error": "Path escapes the disposable lab directory"}), 403

    if not requested.is_file():
        return jsonify({"error": "File not found", "requested": str(requested)}), 404

    return Response(requested.read_text(encoding="utf-8"), mimetype="text/plain")

@app.get("/api/redirect")
def unvalidated_redirect():
    # Intentionally allows an unvalidated redirect target.
    target = request.args.get("url", "https://example.invalid")
    return redirect(target, code=302)

@app.get("/api/debug")
def debug():
    # Fake credentials for data-leak scanner testing. These are not real secrets.
    return jsonify(
        {
            "debug": True,
            "environment": "training",
            "database_password": "FakePassword-For-Scanner-Testing-Only",
            "api_key": "FAKE-CORTEX-LAB-KEY-0000000000000000",
            "internal_note": "Remove verbose debug responses before production.",
        }
    )

if __name__ == "__main__":
    # Keep the intentionally vulnerable service local to the scanner host.
    app.run(host="127.0.0.1", port=5050, debug=False)
