# Cortex API Runtime Vulnerable Lab

This is an intentionally insecure localhost-only Flask API for authorized Cortex Cloud
API Security scanner testing. Do not deploy it to a shared server, cloud platform or
internet-facing host.

## Included test cases

- Reflected HTML input: `GET /api/search?q=petclinic`
- Read-only SQL injection pattern: `GET /api/users?id=1`
- Restricted lab-folder path traversal pattern: `GET /api/files?name=welcome.txt`
- Unvalidated redirect: `GET /api/redirect?url=https://example.invalid`
- Verbose debug response with fake credentials: `GET /api/debug`
- Permissive CORS header added to responses

The path-traversal example is intentionally constrained to this disposable lab folder.
It cannot read arbitrary files outside the extracted bundle.

## Start the API on Windows PowerShell

```powershell
cd .\cortex-api-runtime-vulnerable-lab

py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r .\requirements.txt
py .\app.py
```

The service listens only on:

```text
http://127.0.0.1:5050
```

Leave that terminal running.

## Test the API from a second PowerShell terminal

```powershell
Invoke-RestMethod "http://127.0.0.1:5050/"
Invoke-WebRequest "http://127.0.0.1:5050/api/search?q=petclinic"
Invoke-RestMethod "http://127.0.0.1:5050/api/users?id=1"
Invoke-WebRequest "http://127.0.0.1:5050/api/files?name=../lab_secret.txt"
Invoke-RestMethod "http://127.0.0.1:5050/api/debug"
```

## Run a Cortex Cloud API scan

Run the following from the extracted lab directory. Add your normal Cortex CLI global
authentication options before `api scan` if your CLI installation requires them.

```powershell
cortexcli api scan `
  --scanned-app-url "http://127.0.0.1:5050" `
  --api-spec-file ".\openapi.yaml" `
  --api-spec-type "openapi" `
  --no-publish `
  --output-file ".\cortex-api-report.json"
```

Use `--no-publish` for the initial smoke test. Remove it when you are ready to publish
the results to Cortex Cloud.

## Stop the lab

Return to the terminal running Flask and press `Ctrl+C`.
